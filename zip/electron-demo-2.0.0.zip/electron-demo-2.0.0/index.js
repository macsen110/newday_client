var {callEvent} = require('./tunnel/index.js');
window.callEvent = callEvent;
